Reprendre un projet React : `npm i`

Installer JSON-SERVER : `npm i -g json-server`
Faire tourner le back : `json-server --w src/assets/db.json --port 3004`
