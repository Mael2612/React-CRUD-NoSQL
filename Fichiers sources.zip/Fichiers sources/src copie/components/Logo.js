import React from 'react';

const Logo = () => {
    return (
        <div className='logo'>
            <p>CRUD MINI BLOG</p>
        </div>
    );
};

export default Logo;