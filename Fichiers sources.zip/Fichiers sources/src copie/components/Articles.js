import axios from 'axios';
import React, { useState } from 'react';

const Articles = ({ art }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [editContent, setEditContent] = useState('');
    const dateFormat = (date) => {
        // Pour mettre la date au bon format 
        let newDate = new Date(date).toLocaleDateString('fr-FR', { year: "numeric", month: "long", day: "numeric", hour: "numeric", minute: "numeric", second: "numeric" })
        return newDate;
    };

    const handleEdit = () => {
        setIsEditing(false);
        const data = {
            author: art.author,
            content: editContent ? editContent : art.content,
            date: art.date,
            upadatedDate: Date.now()
        }
        axios.put('http://localhost:3004/articles' + art.id, data).then(() => { setIsEditing(false); })

    };

    const handleDelete = () => {
        axios.delete('http://localhost:3004/articles' + art.id);
        window.location.reload();
    }

    return (
        <div className="article" style={{ background: isEditing ? '#f3feff' : 'white' }}>
            <div className="card-header">
                <h3>{art.author}</h3>
                <p>Posté le : {dateFormat(art.date)}</p>
            </div>
            {/* Zone d'edition de texte  */}
            {isEditing ? (<textarea autoFocus defaultValue={editContent ? editContent : art.content} onChange={(e) => setEditContent(e.target.value)}></textarea>) : (<p>{editContent ? editContent : art.content}</p>)}


            {/* Zone de bouton / ternaire / isEditing ? */}
            <div className="btn-container">
                {isEditing ? <button onClick={() => { handleEdit(); setIsEditing(false) }}>Valider</button>
                    : <button onClick={() => setIsEditing(true)}>Edit</button>
                }
                <button onClick={() => { if (window.confirm('Voulez-vous vraiment supprimer cet article ?')) { handleDelete(); } }}>Supprimer</button>
            </div>
        </div>
    );
};

export default Articles;