import axios from 'axios';
import React, { useEffect, useState } from 'react';
import Articles from '../components/Articles';
import Logo from '../components/Logo';

const Blog = () => {
    const [error, setError] = useState(false);
    const [content, setContent] = useState('');
    const [blog, setBlog] = useState([]);
    const [author, setAuthor] = useState('');

    const getData = () => {
        axios.get('http://localhost:3004/articles')
            .then((res) => setBlog(res.data))
    };

    useEffect(() => getData(), []);

    const handleSubmit = (e) => {
        e.preventDefault()
        if (content.length < 140) {
            setError(true);
        }
        else {
            axios.post('http://localhost:3004/articles', {
                author,
                content,
                date: Date.now()
            });
            setError(false)
            setAuthor('');
            setContent('');
            getData();
        }
    }


    return (
        < div className='blog-container' >
            <Logo />
            <p className='intro'>Application d'un CRUD noSQL avec json-server qui me permet de simuler une base de donnée.</p>

            <form onSubmit={(e) => handleSubmit(e)}>
                <input type="text" placeholder='entrez votre nom' onChange={(e) => setAuthor(e.target.value)} value={author} />
                <textarea placeholder='Message'
                    style={{ border: error ? "1px solid red" : "1px solid #61dafb" }}
                    onChange={(e) => setContent(e.target.value)} value={content}></textarea>
                {error && <p>Veuillez entrer un message de plus de 140 caractères</p>}
                <input type="submit" value='envoyer ' />
            </form>
            <ul>
                {blog
                    .sort((a, b) => b.date - a.date)
                    .map((art) => (<Articles key={art.id} art={art} />))}
            </ul>
        </div >
    );
};

export default Blog;